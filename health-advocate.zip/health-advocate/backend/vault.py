import httpx
import os
from dotenv import load_dotenv

load_dotenv()

VAULT_BASE = f"https://{os.getenv('AUTH0_DOMAIN')}/vault/tokens"
VAULT_HEADERS = {
    "Authorization": f"Bearer {os.getenv('VAULT_API_KEY')}",
    "Content-Type": "application/json"
}


async def get_read_token(user_id: str, service: str) -> str:
    """
    Always available - no step-up needed.
    Used for: reading vitals, fetching records (read-only).
    """
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{VAULT_BASE}/{service}",
            headers={**VAULT_HEADERS, "x-user-id": user_id},
            params={"scope": "read"}
        )
        r.raise_for_status()
        return r.json()["access_token"]


async def get_write_token(user_id: str, service: str, stepup_session_token: str) -> str:
    """
    Only works if a valid step-up session token is provided.
    Used for: booking appointments, sending summaries to doctor.
    """
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{VAULT_BASE}/{service}",
            headers={
                **VAULT_HEADERS,
                "x-user-id": user_id,
                "x-stepup-session": stepup_session_token
            },
            params={"scope": "write"}
        )
        if r.status_code == 403:
            raise PermissionError("step_up_required")
        r.raise_for_status()
        return r.json()["access_token"]


async def revoke_vault_token(user_id: str, service: str):
    """User disconnects a service - token immediately deleted from vault."""
    async with httpx.AsyncClient() as client:
        r = await client.delete(
            f"{VAULT_BASE}/{service}",
            headers={**VAULT_HEADERS, "x-user-id": user_id}
        )
        r.raise_for_status()
        return True


async def list_connected_services(user_id: str) -> list:
    """Returns all services a user has connected via OAuth."""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            VAULT_BASE,
            headers={**VAULT_HEADERS, "x-user-id": user_id}
        )
        r.raise_for_status()
        return r.json().get("tokens", [])
