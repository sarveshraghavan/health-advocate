import os
import google.generativeai as genai
from tools.google_fit import get_heart_rate, get_weekly_vitals
from tools.fhir import get_records, book_appointment, send_summary_to_doctor
from stepup import check_step_up, get_stepup_session_token, request_step_up_url
from dotenv import load_dotenv

load_dotenv()

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("gemini-1.5-flash")

SYSTEM_PROMPT = """You are a careful, privacy-first health advocate assistant.

Rules you MUST follow:
1. NEVER repeat exact numeric values from raw health data in your response
2. NEVER store or reference previous raw data - only refer to summaries
3. NEVER give medical diagnoses - always recommend consulting a doctor
4. Keep responses SHORT and plain-English (2-3 sentences max per topic)
5. If the user asks to take an action (book, send), say what you'll do and check auth

You help users understand health trends, not replace their doctor."""


async def summarize_anomaly(event: str, user_id: str) -> str:
    """
    Called by the watcher when an anomaly is detected.
    Raw event data used only in this LLM call - never persisted.
    """
    prompt = f"{SYSTEM_PROMPT}\n\nHealth alert event: {event}\n\nWrite a 2-sentence plain-English alert for the patient. Do not repeat exact numbers."
    response = model.generate_content(prompt)
    # Only the SUMMARY is returned - raw event string discarded
    return response.text


async def summarize_trend(user_id: str) -> str:
    """
    Fetches raw vitals, summarizes via LLM, discards raw data.
    """
    raw_vitals = await get_weekly_vitals(user_id)
    prompt = f"{SYSTEM_PROMPT}\n\nWeekly vitals data: {raw_vitals}\n\nProvide a brief 2-3 sentence health trend summary. Do not list exact numbers."
    response = model.generate_content(prompt)
    # raw_vitals goes out of scope here - only summary stored in session
    return response.text


async def run_agent(user_id: str, message: str) -> dict:
    """
    Main agent loop. Routes user messages to the right tool.
    Returns response dict with status and message.
    """
    msg_lower = message.lower()

    # READ intents - no step-up needed
    if any(w in msg_lower for w in ["heart rate", "bpm", "vitals", "how am i", "health today"]):
        bpm = await get_heart_rate(user_id)
        prompt = f"{SYSTEM_PROMPT}\n\nCurrent reading: {bpm} BPM\n\nRespond in 1-2 sentences without stating the exact number."
        response = model.generate_content(prompt)
        return {"status": "ok", "response": response.text}

    if any(w in msg_lower for w in ["trend", "week", "summary", "how have i been"]):
        summary = await summarize_trend(user_id)
        return {"status": "ok", "response": summary}

    if any(w in msg_lower for w in ["records", "history", "medical"]):
        records = await get_records(user_id)
        prompt = f"{SYSTEM_PROMPT}\n\nMedical records summary: {records}\n\nSummarise in 2-3 sentences."
        response = model.generate_content(prompt)
        return {"status": "ok", "response": response.text}

    # WRITE intents - step-up required
    if any(w in msg_lower for w in ["book", "appointment", "schedule", "doctor"]):
        if not check_step_up(user_id):
            challenge_url = await request_step_up_url(user_id, "book_appointment")
            return {
                "status": "step_up_required",
                "response": "To book an appointment, I need to verify your identity first. Please complete the biometric check.",
                "challenge_url": challenge_url
            }
        session_token = get_stepup_session_token(user_id)
        result = await book_appointment(user_id, message, session_token)
        return {"status": "ok", "response": f"Appointment booked successfully. Confirmation: {result.get('id', 'N/A')}"}

    if any(w in msg_lower for w in ["send", "share", "doctor", "physician"]):
        if not check_step_up(user_id):
            challenge_url = await request_step_up_url(user_id, "send_summary")
            return {
                "status": "step_up_required",
                "response": "To share your health summary with your doctor, I need to verify your identity first.",
                "challenge_url": challenge_url
            }
        session_token = get_stepup_session_token(user_id)
        summary = await summarize_trend(user_id)
        await send_summary_to_doctor(user_id, summary, session_token)
        return {"status": "ok", "response": "Your health summary has been securely sent to your doctor."}

    # Default: general health question
    prompt = f"{SYSTEM_PROMPT}\n\nUser question: {message}\n\nAnswer helpfully in 2-3 sentences."
    response = model.generate_content(prompt)
    return {"status": "ok", "response": response.text}
